import { createNoteHtmlContainer, sanitizeNoteHtml } from '../../utils/note-html';
import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Capacitor } from '@capacitor/core';
import { Subscription } from 'rxjs';
import { ReminderFiredPayload } from 'src/app/interfaces/reminder';
import { ReminderService } from 'src/app/services/reminder.service';

@Component({
  selector: 'app-reminder-notification',
  templateUrl: './reminder-notification.component.html',
  styleUrls: ['./reminder-notification.component.scss'],
  standalone: false
})
export class ReminderNotificationComponent implements OnInit, OnDestroy {
  notification: ReminderFiredPayload | null = null;
  private sub?: Subscription;
  private bannerResizeObserver?: ResizeObserver;

  @ViewChild('banner')
  set banner(element: ElementRef<HTMLElement> | undefined) {
    this.bannerResizeObserver?.disconnect();
    this.bannerResizeObserver = undefined;

    if (!element) {
      this.clearBannerLayoutState();
      return;
    }

    const updateHeight = () => {
      const height = Math.ceil(element.nativeElement.getBoundingClientRect().height);
      document.documentElement.style.setProperty('--kept-reminder-banner-height', `${height}px`);
      document.body.classList.add('kept-reminder-active');
    };
    updateHeight();
    this.bannerResizeObserver = new ResizeObserver(updateHeight);
    this.bannerResizeObserver.observe(element.nativeElement);
  }

  constructor(private reminderService: ReminderService) {}

  ngOnInit() {
    this.sub = this.reminderService.firedReminder$.subscribe(payload => {
      const cleanPayload = {
        ...payload,
        title: this.cleanText(payload.title),
        body: this.cleanText(payload.body),
        imageUrl: payload.imageUrl || null
      };
      this.notification = cleanPayload;
      this.playReminderSound();
      this.showBrowserNotification(cleanPayload);
    });
  }

  ngOnDestroy() {
    this.sub?.unsubscribe();
    this.bannerResizeObserver?.disconnect();
    this.clearBannerLayoutState();
  }

  dismiss() {
    if (!this.notification) return;
    if (this.notification.reminderId > 0) {
      this.reminderService.dismissFiredReminder(this.notification.reminderId).catch(console.error);
    }
    this.notification = null;
  }

  snooze() {
    if (!this.notification) return;
    const snoozeUntil = new Date(Date.now() + 10 * 60_000).toISOString();
    if (this.notification.reminderId > 0) {
      this.reminderService.update(this.notification.reminderId, { status: 'pending', dueAtUtc: snoozeUntil }).catch(console.error);
    }
    this.notification = null;
  }

  async openNote(payload = this.notification) {
    if (!payload) return;
    const opened = await this.reminderService.openReminderNote(payload.noteId);
    // Opening is navigation, not dismissal or completion of the reminder.
    if (opened && this.notification === payload) this.notification = null;
  }

  private showBrowserNotification(payload: ReminderFiredPayload) {
    // Push notifications are already displayed by the service worker.
    if (payload.source === 'sw-push' || payload.source === 'native') return;

    // Android's native alarm owns system delivery for local timer events.
    // The subscriber still updates the in-app banner and plays its sound.
    if (payload.source === 'local' && Capacitor.getPlatform() === 'android') return;

    if (this.reminderService.isAndroidNativeNotificationAvailable()) {
      this.reminderService.postAndroidReminderNotification(payload).catch(error => {
        console.warn('Android reminder notification failed', error);
        this.showWebNotification(payload);
      });
      return;
    }

    this.showWebNotification(payload);
  }

  private showWebNotification(payload: ReminderFiredPayload) {
    if (typeof window === 'undefined' || !('Notification' in window)) return;
    if (Notification.permission !== 'granted') return;

    const title = this.cleanText(payload.title) || 'Reminder';
    const body = this.cleanText(payload.body);
    try {
      const notification = new Notification(title, {
        body: body || undefined,
        icon: '/assets/images/keep2x.png',
        tag: `kept-reminder-${payload.reminderId}`,
        data: {
          reminderId: payload.reminderId,
          noteId: payload.noteId
        }
      });
      notification.onclick = async () => {
        window.focus();
        try { await this.openNote(payload); }
        catch (error) { console.error('Could not open the reminder note', error); }
        notification.close();
      };
      this.reminderService.trackDisplayedNotification(payload.reminderId, notification);
    } catch {
      // iOS Safari throws if Notification() is constructed in a page context;
      // the SW notification handles iOS anyway.
    }
  }

  private cleanText(value: string | null) {
    const div = createNoteHtmlContainer();
    div.innerHTML = sanitizeNoteHtml(value || '');
    return (div.textContent || div.innerText || '').trim();
  }

  private playReminderSound() {
    const AudioContextCtor = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextCtor) return;

    try {
      const ctx = new AudioContextCtor();
      const notes = [
        { frequency: 659.25, start: 0, duration: 0.09 },
        { frequency: 783.99, start: 0.1, duration: 0.11 },
        { frequency: 1046.5, start: 0.22, duration: 0.16 }
      ];

      notes.forEach(note => {
        const oscillator = ctx.createOscillator();
        const gain = ctx.createGain();
        oscillator.type = 'sine';
        oscillator.frequency.value = note.frequency;
        gain.gain.setValueAtTime(0.0001, ctx.currentTime + note.start);
        gain.gain.exponentialRampToValueAtTime(0.08, ctx.currentTime + note.start + 0.015);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + note.start + note.duration);
        oscillator.connect(gain);
        gain.connect(ctx.destination);
        oscillator.start(ctx.currentTime + note.start);
        oscillator.stop(ctx.currentTime + note.start + note.duration + 0.02);
      });

      setTimeout(() => ctx.close().catch(() => undefined), 700);
    } catch (error) {
      console.log(error);
    }
  }

  private clearBannerLayoutState() {
    document.body.classList.remove('kept-reminder-active');
    document.documentElement.style.removeProperty('--kept-reminder-banner-height');
  }
}
